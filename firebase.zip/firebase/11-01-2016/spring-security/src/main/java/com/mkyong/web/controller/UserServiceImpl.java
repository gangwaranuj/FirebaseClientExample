package com.mkyong.web.controller;

import java.util.ArrayList;
import java.util.Collection;

import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

public class UserServiceImpl implements UserDetailsService{

	@Override
	public UserDetails loadUserByUsername(String arg0) throws UsernameNotFoundException {
		System.out.println(arg0);
		
		Collection<SimpleGrantedAuthority> collections = new ArrayList<SimpleGrantedAuthority>() ;
		
		collections.add(new SimpleGrantedAuthority("ROLE_USER")) ;
		
		
		User user = new User(arg0, "anuj", collections);
		
		return user;
	}

}
