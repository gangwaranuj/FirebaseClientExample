package com.thinksys.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.Gson;
import com.thinksys.demo.bean.Employee;
import com.thinksys.demo.util.ResponseMessage;

@Controller
public class HomeController<ObjectMapper> {


	
	@RequestMapping(value = "/hello", method = RequestMethod.POST)
	@ResponseBody
	public ResponseMessage home(@RequestBody String requestJson,Model model) {

		Gson gson= new Gson();
		ResponseMessage response =new ResponseMessage();
		Employee employee = gson.fromJson(requestJson, Employee.class);
		System.out.println(employee.getName()+" "+ employee.getAddress());
		response.setMsg("Successfully");
		return response;
	}


	@RequestMapping(value = "/xyz", method = RequestMethod.POST)
	public String detail(@RequestBody Employee emp ) {

		
		
		return "home";
	}
}
