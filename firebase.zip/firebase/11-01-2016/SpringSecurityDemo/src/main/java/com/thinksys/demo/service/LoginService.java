package com.thinksys.demo.service;



public interface LoginService {

	public void getLoginDetail();
}
