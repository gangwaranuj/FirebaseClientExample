package com.thinksys.demo.daoImpl;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.thinksys.demo.dao.LoginDao;
import com.thinksys.demo.model.Employee;

@Repository
public class LoginDaoImpl implements LoginDao {
	
	@Autowired
	SessionFactory 	sessionFactory;
	
	@Autowired
	HibernateTemplate hibernateTemplate;
	public void getData(){
		Employee emp=new Employee();
		emp.setName("anuja");
		emp.setPasswod("anuja");
		/*
		Session session = this.sessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		session.persist(emp);
		tx.commit();
		session.close();*/
			
		this.hibernateTemplate.setCheckWriteOperations(false);
		this.hibernateTemplate.save(emp);
		
	}




}
