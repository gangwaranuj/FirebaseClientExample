package com.thinksys.demo.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.thinksys.demo.dao.LoginDao;
import com.thinksys.demo.service.LoginService;


@Service
public class LoginServiceImpl  implements LoginService{

	@Autowired
	LoginDao userDao;
	
	
	@Override
	public void getLoginDetail() {
		this.userDao.getData();
	
	
	}
}
