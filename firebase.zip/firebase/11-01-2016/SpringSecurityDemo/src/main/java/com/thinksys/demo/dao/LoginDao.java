package com.thinksys.demo.dao;


public interface LoginDao {

	public void getData();

}
