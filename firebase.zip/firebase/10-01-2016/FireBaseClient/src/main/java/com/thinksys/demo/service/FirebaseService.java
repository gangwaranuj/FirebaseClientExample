package com.thinksys.demo.service;

import com.thinksys.demo.bean.FirebaseBean;
import com.thinksys.demo.util.ResponseMessage;

public interface FirebaseService {

	public ResponseMessage save(FirebaseBean browserBean);
	
	
	
}
