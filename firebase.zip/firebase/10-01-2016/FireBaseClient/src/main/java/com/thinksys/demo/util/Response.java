 package com.thinksys.demo.util;

public class Response
 {
   
   private Object scalarResult;
   
  
 
   public Object getScalarResult()
   {
     return this.scalarResult;
   }
   
 
   public void setScalarResult(Object scalarResult)
   {
     this.scalarResult = scalarResult;
   }
 }

