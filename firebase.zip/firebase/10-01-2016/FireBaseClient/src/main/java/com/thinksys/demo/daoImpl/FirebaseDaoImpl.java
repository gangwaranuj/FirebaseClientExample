package com.thinksys.demo.daoImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.thinksys.demo.dao.FirebaseDao;
import com.thinksys.demo.model.FirebaseDetail;
import com.thinksys.demo.util.Response;

@Repository
public class FirebaseDaoImpl  implements FirebaseDao{

	@Autowired
	HibernateTemplate hibernateTemplate;
	
	@Transactional
	public Response saveToken(FirebaseDetail tokenDetail) {
		
		Response response = new Response();
		this.hibernateTemplate.setCheckWriteOperations(false);
		int id =(int)this.hibernateTemplate.save(tokenDetail);
		tokenDetail.setId(id);
		response.setScalarResult(tokenDetail);
		return response;
	}

}
