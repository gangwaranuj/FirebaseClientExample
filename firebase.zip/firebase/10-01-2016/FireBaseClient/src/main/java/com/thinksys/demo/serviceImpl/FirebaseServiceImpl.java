package com.thinksys.demo.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.thinksys.demo.bean.FirebaseBean;
import com.thinksys.demo.dao.FirebaseDao;
import com.thinksys.demo.model.FirebaseDetail;
import com.thinksys.demo.service.FirebaseService;
import com.thinksys.demo.util.Response;
import com.thinksys.demo.util.ResponseMessage;

@Service
public class FirebaseServiceImpl implements FirebaseService{


	@Autowired
	FirebaseDao firebaseDao;


	@Override
	public ResponseMessage save(FirebaseBean browserBean) {
		ResponseMessage responseMessage = new ResponseMessage();

		try{
			FirebaseDetail tokenDetail = new FirebaseDetail();
			tokenDetail.setBrowserName(browserBean.getBrowserName());
			tokenDetail.setToken(browserBean.getToken());	
			Response response =this.firebaseDao.saveToken(tokenDetail);
		}
		catch(Exception ex){
			responseMessage.setMsg("Unsuccessfull "+ex.getMessage());
		}
		return responseMessage;
	}

}
