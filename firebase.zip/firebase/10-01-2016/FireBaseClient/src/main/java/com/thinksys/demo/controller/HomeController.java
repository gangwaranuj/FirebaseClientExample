package com.thinksys.demo.controller;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.Gson;
import com.thinksys.demo.bean.FirebaseBean;
import com.thinksys.demo.service.FirebaseService;
import com.thinksys.demo.service.LoginService;
import com.thinksys.demo.util.ResponseMessage;

@Controller
public class HomeController {

	@Autowired
	LoginService loginService;

	@Autowired
	FirebaseService firebaseService;

	/*@RequestMapping(value = {"/welcome"}, method = RequestMethod.GET)
	public ModelAndView welcomePage() {

		ModelAndView model = new ModelAndView();
		model.addObject("title", "xyz");
		model.addObject("message", "welcome");
		model.setViewName("hello");
		this.loginService.getLoginDetail();
		return model;
	}
	@RequestMapping(value = "/admin**", method = RequestMethod.GET)
	public ModelAndView adminPage() {

		ModelAndView model = new ModelAndView();
		model.addObject("title", "Spring Security Custom Login Form");
		model.addObject("message", "This is protected page!");
		model.setViewName("admin");
		return model;
	}

	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public ModelAndView login(@RequestParam(value = "error", required = false) String error,
			@RequestParam(value = "logout", required = false) String logout) {

		System.out.println("in /login");
		ModelAndView model = new ModelAndView();
		if (error != null) {
			model.addObject("error", "Invalid username and password!");
		}
		if (logout != null) {
			model.addObject("msg", "You've been logged out successfully.");
		}
		model.setViewName("login");
		return model;
	}

	 */
	@RequestMapping(value = "/saveToken", method = RequestMethod.POST)
	@ResponseBody
	public ResponseMessage save(@RequestBody String requestJson,HttpServletResponse response) {

		Gson gson= new Gson();

		ResponseMessage responseMessage =new ResponseMessage();
		FirebaseBean browserBean = gson.fromJson(requestJson, FirebaseBean.class);
		responseMessage= this.firebaseService.save(browserBean);

		return responseMessage;
	}

}